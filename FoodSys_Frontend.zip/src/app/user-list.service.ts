import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UserList } from './user-list';

@Injectable({
  providedIn: 'root'
})
export class UserListService implements OnInit {
  private baseURL="http://localhost:8080/api/v1/customer"
  constructor(private httpClient:HttpClient) { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }
  getUserList():Observable<UserList>
  {
    return this.httpClient.get<UserList>(`${this.baseURL}/${'getAll'}`)
  }
  deleteUSerList(id:number):Observable<Object>
  {
    return this.httpClient.delete(`${this.baseURL}/${'deleteCustomer'}/${id}`);
  }
    }