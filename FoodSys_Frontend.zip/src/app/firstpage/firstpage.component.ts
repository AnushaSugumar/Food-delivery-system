import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-firstpage-component',
  templateUrl: './firstpage.component.html',
  styleUrls: ['./firstpage.component.css']
})
export class FirstpageComponent {

  constructor(private router:Router){

  }
  ngOnit(){

  }
  loginroute(){
this.router.navigate(['login'])
  }
  registerroute(){
    this.router.navigate(['register'])
  }
}