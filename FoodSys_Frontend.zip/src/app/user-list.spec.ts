import { UserList } from './user-list';

describe('UserList', () => {
  it('should create an instance', () => {
    expect(new UserList()).toBeTruthy();
  });
});
