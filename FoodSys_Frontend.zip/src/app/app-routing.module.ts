import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterComponent } from './register/register.component';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserListComponent } from './user-list/user-list.component';
import { FoodlistComponent } from './foodlist/foodlist.component';
import { AddfoodComponent } from './addfood/addfood.component';

const routes: Routes = [
  {
    path:'',
    component:FirstpageComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'register',
    component:RegisterComponent
  },
  {
    path:'homepage',
    component:HomepageComponent
  },
  {
    path:'aboutUs',
    component:AboutUsComponent
  },
  {
    path:'adminhome',
    component:AdminhomeComponent
  },
  {
    path:'gallery',
    component:GalleryComponent
  },
  {
    path:'menu',
    component:MenuComponent
  },
  {
    path:'orderdetails',
    component:OrderDetailsComponent
  },
  {
    path:'payment',
    component:PaymentComponent
  },
  {
    path:'user',
    component:UserListComponent
  },
  {
    path:'foodlist',
    component:FoodlistComponent
  },
  {
    path:'addfood',
    component:AddfoodComponent
  },
  {
    path:'contact',
    component:ContactComponent
  },
  {
    path:'home',
    component:HomepageComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }