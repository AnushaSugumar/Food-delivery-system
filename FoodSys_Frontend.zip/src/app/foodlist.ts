export class Foodlist {
    foodId!:number;
    foodName!:string;
    foodprice!:string;
    foodimage!:string;
}

