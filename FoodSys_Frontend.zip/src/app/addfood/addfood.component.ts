import { Component, OnInit } from '@angular/core';
import { FoodlistService } from '../foodlist.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Foodlist } from '../foodlist';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-addfood',
  templateUrl: './addfood.component.html',
  styleUrls: ['./addfood.component.css']
})
export class AddfoodComponent implements OnInit{
  foodList:any;
  editFood: FormGroup;
  foodid:any;
alert:boolean=false;
  constructor(private foodListService : FoodlistService,private router : Router) { 
    this.getFoodList();
    this.editFood = new FormGroup({
      foodId: new FormControl(''),
      foodName: new FormControl(''),
      foodprice: new FormControl('')
    })
  }
  ngOnInit(): void {
   
  }
  getFoodList(){
    this.foodListService.getfoodList().subscribe(data=>{
      console.log(data);
      this.foodList = data;
    });
  };
  Ondelete(id:number){
    this.foodListService.deletefoodList(id).subscribe(res=>{
      console.log(res);
      this.getFoodList();
    });
  };
getData(id:any){

  this.foodid=id;
this.foodListService.getfoodListById(id).subscribe((data:any)=>{
  console.log(data);
  this.editFood.controls['foodId'].setValue(data['foodId']);
  this.editFood.controls['foodName'].setValue(data['foodName']);
  this.editFood.controls['foodprice'].setValue(data['foodprice']);
})
}

Onupdate(){
  var id = this.foodid;
  var foodlist = this.editFood.value;
  this.foodListService.updatefoodList(id,foodlist).subscribe(res=>{
if(res){
  this.getFoodList();
}
  })
}
addRoute(){
  this.router.navigate(['foodlist'])
}
 };