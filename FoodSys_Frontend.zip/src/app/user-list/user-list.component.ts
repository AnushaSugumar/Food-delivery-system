import { Component, OnInit } from '@angular/core';
import { UserListService } from '../user-list.service';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
userList=null;
constructor(private userlistService: UserListService){
this.getUserList();
}
  ngOnInit(): void {
  
  }
  getUserList(){
    this.userlistService.getUserList().subscribe((res:any)=>{
      console.log(res)
      this.userList=res;
    })
  }
  Ondeleted(id:number){
this.userlistService.deleteUSerList(id).subscribe(data=>{
  console.log(data)
  this.getUserList();

})
  }
}