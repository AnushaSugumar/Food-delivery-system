export class Register {
    cId!:number;
    firstname!:string;
    lastname!:string;
    username!:string;
    password!:string;
    email! :string;
    phoneno!:number;
    location!:string;
}

