import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

private baseURL="http://localhost:8080/api/v1/contact;"
  constructor(private httpClient:HttpClient){}

  
  createContact(data:any):Observable<Object>
  {
    return this.httpClient.post(`${this.baseURL}/${'save'}`,data)
  }
 
}